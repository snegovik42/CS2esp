#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string>
#include <vector>
#include <algorithm>

struct Player {
    int x, y, w, h;       // top-left position and box size
    int health;
    std::wstring name;
};

static bool showBox = true;
static bool showName = true;
static bool showHealth = true;
static bool showSkeleton = true;
static HWND g_hwnd = nullptr;
static int g_screenW = 0, g_screenH = 0;

// Demonstration-only entities. These are fabricated coordinates, not read from CS2.
static std::vector<Player> DemoPlayers()
{
    const int w = g_screenW, h = g_screenH;
    return {
        { w * 32 / 100, h * 24 / 100, 90, 220, 86, L"Demo Player 1" },
        { w * 61 / 100, h * 29 / 100, 82, 205, 54, L"Demo Player 2" }
    };
}

static void DrawLine(HDC dc, int x1, int y1, int x2, int y2, COLORREF color, int width = 2)
{
    HPEN pen = CreatePen(PS_SOLID, width, color);
    HGDIOBJ old = SelectObject(dc, pen);
    MoveToEx(dc, x1, y1, nullptr);
    LineTo(dc, x2, y2);
    SelectObject(dc, old);
    DeleteObject(pen);
}

static void DrawTextLabel(HDC dc, int x, int y, const std::wstring& text, COLORREF color)
{
    SetBkMode(dc, TRANSPARENT);
    SetTextColor(dc, RGB(0, 0, 0));
    TextOutW(dc, x + 1, y + 1, text.c_str(), (int)text.size());
    SetTextColor(dc, color);
    TextOutW(dc, x, y, text.c_str(), (int)text.size());
}

static void DrawPlayer(HDC dc, const Player& p)
{
    const COLORREF green = RGB(70, 235, 120);
    const COLORREF white = RGB(245, 245, 245);
    const int x = p.x, y = p.y, w = p.w, h = p.h;

    if (showBox) {
        HPEN pen = CreatePen(PS_SOLID, 2, green);
        HGDIOBJ oldPen = SelectObject(dc, pen);
        HGDIOBJ oldBrush = SelectObject(dc, GetStockObject(HOLLOW_BRUSH));
        Rectangle(dc, x, y, x + w, y + h);
        SelectObject(dc, oldBrush);
        SelectObject(dc, oldPen);
        DeleteObject(pen);
    }

    if (showName)
        DrawTextLabel(dc, x, y - 22, p.name, white);

    if (showHealth) {
        const int barX = x - 9;
        const int barY = y;
        const int barH = h;
        RECT bg{ barX, barY, barX + 5, barY + barH };
        HBRUSH bgBrush = CreateSolidBrush(RGB(45, 45, 45));
        FillRect(dc, &bg, bgBrush);
        DeleteObject(bgBrush);

        const int hp = std::clamp(p.health, 0, 100);
        const int filled = barH * hp / 100;
        RECT fg{ barX, barY + (barH - filled), barX + 5, barY + barH };
        COLORREF hpColor = hp > 60 ? RGB(60, 220, 90) :
                           hp > 30 ? RGB(240, 190, 40) : RGB(235, 65, 65);
        HBRUSH hpBrush = CreateSolidBrush(hpColor);
        FillRect(dc, &fg, hpBrush);
        DeleteObject(hpBrush);
    }

    if (showSkeleton) {
        // Stylized example skeleton, positioned inside the demo box.
        const int cx = x + w / 2;
        const int headY = y + h / 10;
        const int neckY = y + h / 5;
        const int chestY = y + h * 2 / 5;
        const int hipY = y + h * 3 / 5;
        const int kneeY = y + h * 4 / 5;
        const int footY = y + h - 3;

        const int shoulderL = x + w / 5, shoulderR = x + w * 4 / 5;
        const int elbowL = x + w / 10, elbowR = x + w * 9 / 10;
        const int handL = x + 2, handR = x + w - 2;
        const int hipL = x + w * 2 / 5, hipR = x + w * 3 / 5;
        const int kneeL = x + w / 3, kneeR = x + w * 2 / 3;
        const int footL = x + w / 4, footR = x + w * 3 / 4;

        const COLORREF bone = RGB(255, 210, 70);
        // Head
        HBRUSH headBrush = CreateSolidBrush(bone);
        HGDIOBJ oldBrush = SelectObject(dc, headBrush);
        HGDIOBJ oldPen = SelectObject(dc, GetStockObject(NULL_PEN));
        Ellipse(dc, cx - 9, y + 3, cx + 9, y + h / 7);
        SelectObject(dc, oldPen);
        SelectObject(dc, oldBrush);
        DeleteObject(headBrush);

        DrawLine(dc, cx, neckY, cx, hipY, bone);
        DrawLine(dc, cx, chestY, shoulderL, neckY + 8, bone);
        DrawLine(dc, shoulderL, neckY + 8, elbowL, chestY, bone);
        DrawLine(dc, elbowL, chestY, handL, chestY + 22, bone);
        DrawLine(dc, cx, chestY, shoulderR, neckY + 8, bone);
        DrawLine(dc, shoulderR, neckY + 8, elbowR, chestY, bone);
        DrawLine(dc, elbowR, chestY, handR, chestY + 22, bone);
        DrawLine(dc, cx, hipY, hipL, hipY, bone);
        DrawLine(dc, hipL, hipY, kneeL, kneeY, bone);
        DrawLine(dc, kneeL, kneeY, footL, footY, bone);
        DrawLine(dc, cx, hipY, hipR, hipY, bone);
        DrawLine(dc, hipR, hipY, kneeR, kneeY, bone);
        DrawLine(dc, kneeR, kneeY, footR, footY, bone);
    }
}

static void Render(HDC dc)
{
    // Black is the transparent color key for this layered window.
    RECT all{ 0, 0, g_screenW, g_screenH };
    HBRUSH black = CreateSolidBrush(RGB(0, 0, 0));
    FillRect(dc, &all, black);
    DeleteObject(black);

    for (const auto& p : DemoPlayers())
        DrawPlayer(dc, p);

    DrawTextLabel(dc, 18, 18,
        L"CS2 Overlay demo | F1 Box  F2 Name  F3 Health  F4 Skeleton  END Exit",
        RGB(180, 220, 255));
}

static LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_TIMER:
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    case WM_KEYDOWN:
        switch (wp) {
        case VK_F1: showBox = !showBox; break;
        case VK_F2: showName = !showName; break;
        case VK_F3: showHealth = !showHealth; break;
        case VK_F4: showSkeleton = !showSkeleton; break;
        case VK_END: DestroyWindow(hwnd); return 0;
        }
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    case WM_PAINT: {
        PAINTSTRUCT ps{};
        HDC dc = BeginPaint(hwnd, &ps);
        Render(dc);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_DESTROY:
        KillTimer(hwnd, 1);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int)
{
    g_screenW = GetSystemMetrics(SM_CXSCREEN);
    g_screenH = GetSystemMetrics(SM_CYSCREEN);

    const wchar_t CLASS_NAME[] = L"CS2OverlayDemoWindow";
    WNDCLASSW wc{};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = instance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassW(&wc);

    // Transparent, topmost, click-through overlay. It does not attach to or inspect CS2.
    g_hwnd = CreateWindowExW(
        WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
        CLASS_NAME, L"CS2 Overlay Demo", WS_POPUP,
        0, 0, g_screenW, g_screenH,
        nullptr, nullptr, instance, nullptr);

    if (!g_hwnd) return 1;

    SetLayeredWindowAttributes(g_hwnd, RGB(0, 0, 0), 0, LWA_COLORKEY);
    ShowWindow(g_hwnd, SW_SHOW);
    UpdateWindow(g_hwnd);
    SetTimer(g_hwnd, 1, 16, nullptr);

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return 0;
}
